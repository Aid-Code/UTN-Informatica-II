################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../Drivers/PerifericoTemporizado.cpp \
../Drivers/Timer.cpp \
../Drivers/gpio.cpp 

CPP_DEPS += \
./Drivers/PerifericoTemporizado.d \
./Drivers/Timer.d \
./Drivers/gpio.d 

OBJS += \
./Drivers/PerifericoTemporizado.o \
./Drivers/Timer.o \
./Drivers/gpio.o 


# Each subdirectory must supply rules for building sources it contributes
Drivers/%.o: ../Drivers/%.cpp Drivers/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C++ Compiler'
	arm-none-eabi-c++ -DDEBUG -D__CODE_RED -D__NEWLIB__ -DCORE_M0PLUS -D__MTB_DISABLE -D__MTB_BUFFER_SIZE=256 -DCPP_USE_HEAP -D__LPC84X__ -I"C:\Users\jesco\Documents\Info II\MCUXpresso_CL2026\ProyectoBase_Parcial.zip_expanded\ProyectoBase\Drivers" -I"C:\Users\jesco\Documents\Info II\MCUXpresso_CL2026\ProyectoBase_Parcial.zip_expanded\ProyectoBase\Firmware" -I"C:\Users\jesco\Documents\Info II\MCUXpresso_CL2026\ProyectoBase_Parcial.zip_expanded\ProyectoBase\Aplicacion" -O0 -fno-common -g3 -gdwarf-4 -Wall -c -fmessage-length=0 -fno-builtin -ffunction-sections -fdata-sections -fno-rtti -fno-exceptions -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m0 -mthumb -fstack-usage -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-Drivers

clean-Drivers:
	-$(RM) ./Drivers/PerifericoTemporizado.d ./Drivers/PerifericoTemporizado.o ./Drivers/Timer.d ./Drivers/Timer.o ./Drivers/gpio.d ./Drivers/gpio.o

.PHONY: clean-Drivers

